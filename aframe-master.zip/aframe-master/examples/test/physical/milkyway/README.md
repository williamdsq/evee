These images were taken from the three.js Github repository, which is licensed
by the three.js authors.
