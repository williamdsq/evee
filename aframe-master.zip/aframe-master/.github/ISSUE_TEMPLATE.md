**Description:**

- A-Frame Version:
- Platform / Device:
- Reproducible Code Snippet or URL:

<!-- If you have a support question, please ask at https://stackoverflow.com/questions/ask/?tags=aframe rather than filing an issue. -->
