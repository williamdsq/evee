Node integration tests. Not run with Karma.
